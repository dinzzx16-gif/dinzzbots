module.exports = {
  BOT_TOKEN: "TOKEN_BOT",
  OWNER_ID: ["ID_TELE"],
  REQUIRED_CHANNELS: [
  {
    id: "@Channel_lu",
    url: "https://t.me/channel_lu",
    name: "Althera Channel"
  }
  ]
};